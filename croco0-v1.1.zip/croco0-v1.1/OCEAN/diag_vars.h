       real Cu_Adv
       real Cu_W
       integer i_cx_max
       integer j_cx_max
       integer k_cx_max
       integer node_max

       common /diag_vars/Cu_Adv,Cu_W
       common /diag_vars2/i_cx_max,
     &                 j_cx_max,k_cx_max,node_max
