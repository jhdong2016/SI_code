#!/bin/bash

#======================
source CONFIGURE_GLOBAL
#======================

cd  $SOURCE_CROCO/..
#/usr/bin/git checkout
/usr/bin/git pull
cd -

