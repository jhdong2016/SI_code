#!/bin/bash

\rm jobcomp* cppdefs.h* AGRIF_FixedGrids.in croco
\rm *.pdf
\rm *.nc
\rm *.nc.?
\rm -rf LOG TEST_CASES Compile
